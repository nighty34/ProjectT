Surge
http://surge.pixelplacement.com

A collection of free tools to help take your Unity development to another level so you can get things done faster.

Tween
Animate anything with style and just one line of code.

State Machine
Logical, visual, sane, organization for turning small things into powerful solutions.

Singleton
Simplified global access, streamlined solution development and portable, reusable tool creation at your fingertips.

Display Object
Ultimate control for visual content availability.

Spline
Powerful and elegant tools for visualing a spline, moving objects along a complex path, controlling particles systems and more!

Collider Button
A unified button solution that operates as expected across any and all platforms from mobile to virtual reality.

Chooser
The complete solution for identifying and responding to pointing or gazing.